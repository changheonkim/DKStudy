package day9;

interface Rentable {
	public void rent();
}
